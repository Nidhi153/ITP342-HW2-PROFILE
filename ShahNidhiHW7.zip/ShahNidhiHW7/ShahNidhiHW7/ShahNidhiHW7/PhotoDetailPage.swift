//
//  PhotoDetailPage.swift
//  ShahNidhiHW7
//
//  Created by Student on 3/22/24.
//

import SwiftUI

struct PhotoDetailPage: View {
    let photo: Photo
    var body: some View {
        PhotoDetailView(url: photo.urls.regular)
    }
}

struct PhotoDetailPage_Previews: PreviewProvider {
    static var previews: some View {
        Text("Hello World!")
//        PhotoDetailPage()
    }
}
