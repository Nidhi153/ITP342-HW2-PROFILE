//
//  PhotoCell.swift
//  ShahNidhiHW7
//
//  Created by Student on 3/22/24.
//

import SwiftUI
import Kingfisher

struct PhotoCell: View {
    let photo: Photo
    var body: some View {
        NavigationLink(value:photo) {
            KFImage(URL(string:photo.urls.regular))
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(minWidth: 0,maxWidth: .infinity)
                .frame(height: 160)
                .clipped()
        }
    }
}

struct PhotoCell_Previews: PreviewProvider {
    static var previews: some View {
        KFImage(URL(string:"https://images.unsplash.com/photo-1682687982107-14492010e05e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w1ODIzMDl8MXwxfGFsbHwxfHx8fHx8Mnx8MTcxMTE0MjA0MHw&ixlib=rb-4.0.3&q=80&w=1080"))
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(minWidth: 0,maxWidth: .infinity)
            .frame(height: 160)
            .clipped()
//        PhotoCell()
    }
}
