//
//  PhotoGridPage.swift
//  ShahNidhiHW7
//
//  Created by Student on 3/22/24.
//

import SwiftUI

struct PhotoGridPage: View {
    @StateObject var photosViewModel: PhotosViewModel = PhotosViewModel()
    
    @State var viewDidLoad: Bool = false
    
    let items = [GridItem(.flexible(minimum:120)), GridItem(.flexible(minimum:120))]
    var body: some View {
        ScrollView {
            VStack(spacing:10) {
                if (photosViewModel.isLoading) {
                    ProgressView()
                }
                else {
                    LazyVGrid(columns: items) {
                        ForEach(photosViewModel.photos, id:\.self) { photo in
                            PhotoCell(photo: photo)
                        }
                    }
                    .padding()
                }
            }
        }
        .task {
            if (viewDidLoad == false) {
                do {
                    try await photosViewModel.refresh()
                    
                    viewDidLoad = true
                } catch {
                    print(error)
                }
            }
        }
        .navigationTitle("Unsplash Feed")
        .toolbar() {
            Button {
                Task {
                    do {
                        try await photosViewModel.refresh()
                        
                        viewDidLoad = true
                    } catch {
                        print(error)
                    }
                }
            } label: {
                Image(systemName: "arrow.clockwise")
            }
        }
    }
}

struct PhotoGridPage_Previews: PreviewProvider {
    static var previews: some View {
//        ProgressView()
        PhotoGridPage()
    }
}
