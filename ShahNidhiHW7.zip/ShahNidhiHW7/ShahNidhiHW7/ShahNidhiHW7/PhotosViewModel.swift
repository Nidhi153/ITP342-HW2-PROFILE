//
//  PhotosViewModel.swift
//  ShahNidhiHW7
//
//  Created by Student on 3/22/24.
//

import Foundation

class PhotosViewModel : ObservableObject {
    private let BASE_URL: String = "https://api.unsplash.com"
    private let ACCESS_KEY: String = "lkQuWOgC95uv5SrFG1OMDNJ91EykPtHYGj1vuzthBg0"
    private let PHOTOS_COUNT: Int = 20
    
    @Published var isLoading = false
    
    @Published var photos: [Photo] = []
    
    func refresh() async throws {
        let url = URL(string: "\(BASE_URL)/photos/random?client_id=\(ACCESS_KEY)&count=\(PHOTOS_COUNT)")!
        let urlRequest = URLRequest(url: url)
//        urlRequest.setValue("CLIENT-ID \(ACCESS_KEY)", forHTTPHeaderField: "Authorization")
        
        do {
            self.isLoading = true
            let (data,_) = try await URLSession.shared.data(for: urlRequest)
            print("data: \(data)")
            let decoder = JSONDecoder()
            let images: [Photo] = try decoder.decode([Photo].self, from: data)
            self.isLoading = false
            self.photos = images
            print(photos)
        } catch {
            print(error)
            self.isLoading = false
        }
    }
}
