//
//  PhotoNavContainer.swift
//  ShahNidhiHW7
//
//  Created by Student on 3/22/24.
//

import SwiftUI

struct PhotoNavContainer: View {
    var body: some View {
        NavigationStack {
            PhotoGridPage()
                .navigationDestination(for: Photo.self) {
                    PhotoDetailPage(photo:$0)
                }
        }
    }
}

struct PhotoNavContainer_Previews: PreviewProvider {
    static var previews: some View {
        PhotoNavContainer()
    }
}
