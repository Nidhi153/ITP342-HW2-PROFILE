//
//  Photo.swift
//  ShahNidhiHW7
//
//  Created by Student on 3/22/24.
//

import Foundation

struct PhotoUrl : Decodable, Hashable {
    let raw: String
    let full: String
    let regular: String
    let small: String
    let thumb: String
    
    static func == (lhs: PhotoUrl, rhs: PhotoUrl) -> Bool {
        return lhs.raw == rhs.raw && lhs.full == rhs.full && lhs.regular==rhs.regular && lhs.small == rhs.small && lhs.thumb==rhs.thumb
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(raw)
        hasher.combine(full)
        hasher.combine(regular)
        hasher.combine(small)
        hasher.combine(thumb)
    }
}

struct Photo : Decodable, Hashable, Identifiable {
    let id: String
    let urls: PhotoUrl
    
    static func == (lhs: Photo, rhs: Photo) -> Bool {
        return lhs.id == rhs.id && lhs.urls == rhs.urls
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(urls)
    }
}
