//
//  ShahNidhiHW7App.swift
//  ShahNidhiHW7
//
//  Created by Student on 3/22/24.
//

import SwiftUI

@main
struct ShahNidhiHW7App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
