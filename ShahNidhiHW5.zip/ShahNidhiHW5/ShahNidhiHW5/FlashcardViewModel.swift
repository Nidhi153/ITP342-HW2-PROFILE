//
//  FlashcardViewModel.swift
//  ShahNidhiHW5
//
//  Created by Student on 2/18/24.
//

import Foundation

class FlashcardViewModel: FlashcardsModel, ObservableObject {
    
    var flashcards: [Flashcard]
    
    var numberOfFlashcards: Int {
        return flashcards.count
    }
    
    init() {
        flashcards = [
            Flashcard(id:UUID().uuidString, question:"Capital of China", answer:"Beijing", isFavorite:false),
            Flashcard(id:UUID().uuidString, question:"Capital of USA", answer:"Washington DC", isFavorite:false),
            Flashcard(id:UUID().uuidString, question:"Capital of India", answer:"Delhi", isFavorite:false),
            Flashcard(id:UUID().uuidString, question:"Capital of Australia", answer:"Canberra", isFavorite:false),
            Flashcard(id:UUID().uuidString, question:"Capital of Spain", answer:"Madrid", isFavorite:false),
        ]
    }
    
    @Published var currentIndex = 0 {
        didSet {
            switch (currentIndex) {
            case flashcards.count...:
                currentIndex=0
            default:
                print("")
            }
        }
    }
    
    var currentFlashcard: Flashcard? {
        if (flashcards.count != 0) {
            return flashcards[currentIndex]
        }
        return nil
    }
    
    var favoriteFlashcards: [Flashcard] {
        flashcards.filter{$0.isFavorite}
    }
    
    func getIndex(for flashcard: Flashcard) -> Int? {
        var i = 0
        while (i<numberOfFlashcards) {
            if (flashcards[i] == flashcard) {
                return i
            }
            i+=1
        }
        return nil
    }
    
    func randomize() {
        currentIndex = Int.random(in: 0..<flashcards.count)
        //use a while loop?
    }
    
    func next() {
        currentIndex+=1
        if (currentIndex >= flashcards.count) {
            currentIndex = 0
        }
    }
    
    func previous() {
        if (currentIndex == 0) {
            currentIndex = flashcards.count-1
        }
        else {
            currentIndex -= 1
        }
    }
    
    func flashcard(at index: Int) -> Flashcard? {
        if (index < 0 || index >= flashcards.count) {
            return nil
        }
        return flashcards[index]
    }
    
    func append(flashcard: Flashcard) {
        flashcards.append(flashcard)
    }
    
    func insert(flashcard: Flashcard, at index: Int) {
        flashcards.append(flashcard)
        if (index < 0 || index >= flashcards.count) {
            return
        }
        for i in stride(from:numberOfFlashcards-1, through:index+1, by:-1){
            flashcards[i] = flashcards[i-1]
        }
        flashcards[index] = flashcard
    }
    
    func removeFlashcard(at index: Int) {
        if (index < 0 || index >= flashcards.count) {
            return
        }
        flashcards.remove(at: index)
    }
    
    func toggleFavorite() {
        let currentCard: Flashcard = flashcards[currentIndex]
        let newCard: Flashcard = Flashcard(id: currentCard.id, question: currentCard.question, answer: currentCard.answer, isFavorite: !currentCard.isFavorite)
        self.update(flashcard: newCard, at: currentIndex)
        //do i need to destroy current card?
    }
    
    func update(flashcard: Flashcard, at index: Int) {
        if (index < 0 || index >= numberOfFlashcards) {
//            flashcards.append(flashcard)
            return
        }
        self.removeFlashcard(at: index)
        self.insert(flashcard: flashcard, at: index)
//        flashcards[index].id = flashcard.id
//        flashcards[index].question = flashcard.question
//        flashcards[index].answer = flashcard.answer
//        flashcards[index].isFavorite = flashcard.isFavorite
    }
}
