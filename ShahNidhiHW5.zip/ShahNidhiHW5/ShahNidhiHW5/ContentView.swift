//
//  ContentView.swift
//  ShahNidhiHW5
//
//  Created by Student on 2/18/24.
//

import SwiftUI



struct ContentView: View {
    let OFFSET_X = 300.0
    let OFFSET_Y = 900.0
    
    @StateObject var flashcardViewModel = FlashcardViewModel()
    @State var isShowingQuestion = true
    @State var offsetX = 0.0
    @State var offsetY = 0.0
    @State var isHidden = false
    
    var title: String {
        if (flashcardViewModel.currentFlashcard == nil)  {
            return ""
        }
        if (isShowingQuestion) {
            return flashcardViewModel.currentFlashcard!.question
        }
        return flashcardViewModel.currentFlashcard!.answer
    }
    
    func showRandomFlashcard() {
        let Duration=0.5
        withAnimation(.linear(duration:Duration)) {
            isHidden = false
            offsetY = -OFFSET_Y
            isHidden = true
        }
        
        withAnimation(.linear(duration: Duration).delay(Duration)) {
            offsetY = OFFSET_Y
            flashcardViewModel.randomize()
            isShowingQuestion = true
        }
        withAnimation(.linear(duration: Duration).delay(Duration*2)) {
            isHidden = false
            offsetY = 0.0
        }
    }
    
    func toggleQuestionAnswer() {
        withAnimation(.linear(duration: 0.5)) {
            //fade out
            isHidden = true
            
            //switch to answer
            isShowingQuestion = !isShowingQuestion
            
            //fade out
            isHidden = false
        }
    }
    
    func showNextCard() {
        let Duration=0.5
        withAnimation(.linear(duration:Duration)) {
            isHidden = false
            offsetX = -OFFSET_X
            isHidden = true
        }
        withAnimation(.linear(duration: Duration).delay(Duration)) {
            offsetX = OFFSET_X
            flashcardViewModel.next()
            isShowingQuestion = true
        }
        withAnimation(.linear(duration: Duration).delay(Duration*2)) {
            isHidden = false
            offsetX = 0.0
        }
    }
    
    func showPreviousCard() {
        let Duration=0.5
        
        withAnimation(.linear(duration:Duration)) {
            isHidden = false
            offsetX = OFFSET_X
            isHidden = true
        }
        
        withAnimation(.linear(duration: Duration).delay(Duration)) {
            offsetX = -OFFSET_X
            isShowingQuestion = true
            flashcardViewModel.previous()
        }
        

        withAnimation(.linear(duration: Duration).delay(Duration*2)) {
            isHidden = false
            offsetX = 0.0
        }
    }
    
    var body: some View {
        VStack {
            Text("\(title)")
                .font(.largeTitle)
                .bold()
                .foregroundColor(isShowingQuestion ? Color.black : Color.indigo)
        }
        .frame(maxWidth:.infinity,  maxHeight: .infinity)
        .background(Color.teal)
        .opacity(isHidden ? 0 : 1)
        .offset(x:offsetX,y:offsetY)
        .padding()
        .onTapGesture(count: 2) {
            toggleQuestionAnswer()
        }
        .onTapGesture {
            //move vertically
            showRandomFlashcard()
        }
        .gesture(DragGesture(minimumDistance: 3.0, coordinateSpace: .local)
                .onEnded { value in
                    print(value.translation)
                    switch(value.translation.width, value.translation.height) {
                        case (...0, -30...30):
                            print("left swipe") // show next card here
                            showNextCard()
                        case (0..., -30...30):
                            print("right swipe") // show previous card here
                            showPreviousCard()
                        case (-100...100, ...0):
                            print("up swipe")
                        case (-100...100, 0...):
                            print("down swipe")
                        default:
                            print("no clue")
                    }
                }
            )
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
