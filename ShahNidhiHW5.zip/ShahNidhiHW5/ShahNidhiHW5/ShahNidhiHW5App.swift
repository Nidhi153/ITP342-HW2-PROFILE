//
//  ShahNidhiHW5App.swift
//  ShahNidhiHW5
//
//  Created by Student on 2/18/24.
//

import SwiftUI

@main
struct ShahNidhiHW5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
