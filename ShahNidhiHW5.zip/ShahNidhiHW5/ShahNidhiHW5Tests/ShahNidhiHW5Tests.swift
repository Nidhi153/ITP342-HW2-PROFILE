//
//  ShahNidhiHW5Tests.swift
//  ShahNidhiHW5Tests
//
//  Created by Student on 2/18/24.
//

import XCTest
@testable import ShahNidhiHW5

final class ShahNidhiHW5Tests: XCTestCase {
    var fcViewModel = FlashcardViewModel()
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        fcViewModel = FlashcardViewModel()
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    //write tests for each method in FlashcardViewModel
    
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    
    // var numberOfFlashcards
    func testNumberOfFlashcards() throws {
        XCTAssertEqual(5, fcViewModel.numberOfFlashcards)
    }
     
     // var currentFlashcard: Flashcard? { get }
    func testCurrentFlashcard() throws {
        fcViewModel = FlashcardViewModel()
        fcViewModel.currentIndex=0
        
        XCTAssertEqual(fcViewModel.currentFlashcard, fcViewModel.flashcards[0])
    }

    // Returns flashcards that has been marked as favorited
     // var favoriteFlashcards: [Flashcard] { get }
    func testFavoriteFlashcard() throws {
        let favCards = fcViewModel.favoriteFlashcards
        for favCard in favCards {
            XCTAssertEqual(favCard.isFavorite, true)
        }
        for card in fcViewModel.flashcards{
            if (favCards.contains(card)) {
                continue
            }
            XCTAssertEqual(card.isFavorite, false)
        }
    }
    
     // Randomizes the currentIndex
     // func randomize()
    func testRandomize() throws {
        fcViewModel.randomize()
        
        XCTAssertTrue((fcViewModel.currentIndex>=0 && fcViewModel.currentIndex < fcViewModel.numberOfFlashcards))
        
    }
     
     // Set currentIndex to be next
         // if currentIndex reaches the end of array
         // it should loop back to the beginning of array
     // func next()
    func testNextNormal() throws {
        fcViewModel.currentIndex = 0
        
        fcViewModel.next()
        
        XCTAssertEqual(1, fcViewModel.currentIndex)
        
    }
    
    func testNextEdge() throws {
        fcViewModel.currentIndex = fcViewModel.numberOfFlashcards-1
        
        fcViewModel.next()
        
        XCTAssertEqual(0, fcViewModel.currentIndex)
        
    }
     
     // Set currentIndex to be previous
         // if currentIndex reaches past the beginning
         // it should loop back to the end of array
     // func previous()
    func testPreviousNormal() throws {
        fcViewModel.currentIndex = 1
        
        fcViewModel.previous()
        
        XCTAssertEqual(0, fcViewModel.currentIndex)
    }
    func testPreviousEdge() throws {
        fcViewModel.currentIndex = 0
        
        fcViewModel.previous()
        
        XCTAssertEqual(fcViewModel.numberOfFlashcards-1, fcViewModel.currentIndex)
    }
    
     // Returns a flashcard at a given index
     // func flashcard(at index: Int) -> Flashcard?
    func testFlashcardAt() throws {
        let fcs: [Flashcard]  = fcViewModel.flashcards
        let ind = Int.random(in:0..<fcViewModel.numberOfFlashcards)
        XCTAssertEqual(fcs[ind], fcViewModel.flashcard(at: ind))
    }
    
     // Initializes a flashcard at end of your flashcards array
     // func append(flashcard: Flashcard)
    func testAppend() throws {
        let initialLength: Int = fcViewModel.numberOfFlashcards
        let flashcard = Flashcard(id: UUID().uuidString, question: "Capital of France", answer: "Paris", isFavorite: false)
        
        fcViewModel.append(flashcard: flashcard)
        
        XCTAssertEqual(flashcard, fcViewModel.flashcards[initialLength])
        XCTAssertEqual(initialLength+1, fcViewModel.numberOfFlashcards)
    }

     // Initializes a flashcard at specific index of your flashcards array
     // func insert(flashcard: Flashcard, at index: Int)
    func testInsert() throws {
        fcViewModel = FlashcardViewModel()
        let ind = 3
        let flashcardBefore = fcViewModel.flashcard(at: ind-1)
        let flashcard = Flashcard(id: UUID().uuidString, question: "Capital of France", answer: "Paris", isFavorite: false)
        let flashcardAfter = fcViewModel.flashcard(at: ind)

        fcViewModel.insert(flashcard: flashcard, at: ind)
        
        XCTAssertEqual(flashcard, fcViewModel.flashcard(at: ind))
        
        XCTAssertEqual(flashcardBefore, fcViewModel.flashcard(at: ind-1))
        XCTAssertEqual(flashcardAfter, fcViewModel.flashcard(at: ind+1))
        
    }

     // Removes flashcard at a specific index
     // func removeFlashcard(at index: Int)
    func testRemove() throws {
        fcViewModel = FlashcardViewModel() // has length 5
        let initialLength: Int = fcViewModel.numberOfFlashcards
        let flashcard = fcViewModel.flashcard(at: 3)
        
        fcViewModel.removeFlashcard(at: 3)
        
        XCTAssertNotEqual(flashcard, fcViewModel.flashcard(at:3))
        XCTAssertEqual(initialLength-1, fcViewModel.numberOfFlashcards)
    }

     // Returns an index for a given flashcard
     // func getIndex(for flashcard: Flashcard) -> Int?
    func testGetIndex() throws {
        fcViewModel = FlashcardViewModel() // has length 5
        
        let ind = Int.random(in:0..<fcViewModel.numberOfFlashcards)
        let flashcard = fcViewModel.flashcard(at: ind)
        let receivedInd = fcViewModel.getIndex(for: flashcard!)
        
        XCTAssertEqual(ind, receivedInd)
    }

     // Updates a flashcard at a specific index
     // func update(flashcard: Flashcard, at index: Int)
    func testUpdate() throws {
        let initialLength: Int = fcViewModel.numberOfFlashcards
        let flashcard = Flashcard(id: UUID().uuidString, question: "Capital of France", answer: "Paris", isFavorite: false)
        
        fcViewModel.update(flashcard: flashcard, at: 3)
        
        XCTAssertEqual(flashcard.question, fcViewModel.flashcards[3].question)
        XCTAssertEqual(flashcard.answer, fcViewModel.flashcards[3].answer)
        XCTAssertEqual(flashcard.isFavorite, fcViewModel.flashcards[3].isFavorite)
        XCTAssertEqual(initialLength, fcViewModel.numberOfFlashcards)
    }

     // Toggles the favorite attribute of your flashcard
     // func toggleFavorite()
    func testToggleFavorite() throws {
        let currentSetting = fcViewModel.currentFlashcard?.isFavorite
        
        fcViewModel.toggleFavorite()
        
        XCTAssertNotEqual(currentSetting, fcViewModel.currentFlashcard?.isFavorite)
    }
    

//    func testPerformanceExample() throws {
//        // This is an example of a performance test case.
//        self.measure {
//            // Put the code you want to measure the time of here.
//        }
//    }

}
