//
//  ShahNidhiHW4App.swift
//  ShahNidhiHW4
//
//  Created by Student on 2/8/24.
//

import SwiftUI

@main
struct ShahNidhiHW4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
