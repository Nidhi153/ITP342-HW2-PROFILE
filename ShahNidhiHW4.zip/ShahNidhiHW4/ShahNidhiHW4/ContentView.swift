//
//  ContentView.swift
//  ShahNidhiHW4
//
//  Created by Student on 2/8/24.
//

import SwiftUI

enum TaxPercentage: Double {
    case sevenFive = 7.5, eight = 8, eightFive = 8.5, nine = 9, nineFive = 9.5
}

extension Double {
    var formattedCurrency : String {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .currency
        numberFormatter.maximumFractionDigits = 2
        return  numberFormatter.string(from: NSNumber(value: self)) ?? ""
    }
}

//func calculate(bill: String, taxPercent: Double, tipPercent: Double) {
//
//    var billAmount : Double = (bill as NSString).doubleValue
//
//    return billAmount
//
//}

struct ContentView: View {
    //Binded Values
    @FocusState private var isFocused : Bool
    @State private var bill = "0"
    @State private var taxPercent = TaxPercentage.sevenFive
    @State private var isTaxIncludedInSubtotal = true
    @State private var tipPercent = 20.0
    @State private var numSplit = 1
    
    //Calculated Amounts
    var billAmount : Double {
        if let billAmount = Double(bill) {
            return billAmount
        }
        return  0.0
    }
    var taxAmount : Double {
        return taxPercent.rawValue/100*billAmount
    }
    var subtotalAmount : Double {
        if isTaxIncludedInSubtotal {
            return taxAmount+billAmount
        }
        return billAmount
    }
    var tipAmount : Double {
        return subtotalAmount*Double(Int(tipPercent))/100
    }
    var totalWithTipAmount : Double {
        return billAmount+taxAmount+tipAmount
    }
    var totalPerPersonAmount : Double {
        return totalWithTipAmount / Double(numSplit)
    }
    
    
    var body: some View {
        VStack(spacing:16) {
            Spacer()
            TextField("Bill Amount", text: $bill)
                .focused($isFocused)
                .keyboardType(.decimalPad)
            
            Picker("Tax %", selection: $taxPercent) {
                Text("7.5").tag(TaxPercentage.sevenFive)
                Text("8").tag(TaxPercentage.eight)
                Text("8.5").tag(TaxPercentage.eightFive)
                Text("9").tag(TaxPercentage.nine)
                Text("9.5").tag(TaxPercentage.nineFive)
            }
            .pickerStyle(.segmented)
            
            Toggle("Include Tax in Subtotal", isOn: $isTaxIncludedInSubtotal)
            
            HStack {
                Text("Tip % \(Int(tipPercent))")
                Slider(value: $tipPercent, in:0...100)
                
            }
            Stepper("Split \(numSplit)", value: $numSplit, in: 1...20)
            
            HStack{
                Spacer()
                VStack(alignment: .trailing, spacing:16) {
                    Text("**Tax** \(taxAmount.formattedCurrency)")
                    Text("**Subtotal** \(subtotalAmount.formattedCurrency)")
                    Text("**Tip** \(tipAmount.formattedCurrency)")
                    
                    Text("**Total with Tip** \(totalWithTipAmount.formattedCurrency)")
                    Text("**Total per Person** \(totalPerPersonAmount.formattedCurrency)")
                }
            }
            
            Button("Clear All") {
                isFocused = false
                bill = "0"
                taxPercent = TaxPercentage.sevenFive
                tipPercent = 20.0
                numSplit = 1
                isTaxIncludedInSubtotal = true
                
            }
            .frame(maxWidth: .infinity)
            .padding(16)
            .background(.white)
        }
        .contentShape(Rectangle())
        .padding(16)
        .background(Color.yellow)
        .font(.title3)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
