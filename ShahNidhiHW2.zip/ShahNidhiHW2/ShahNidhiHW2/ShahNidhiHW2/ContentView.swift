//
//  ContentView.swift
//  ShahNidhiHW2
//
//  Created by Student on 1/28/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing:30) {
            Text("Nidhi Pankaj Shah").font(.title)
            Image("SHAH_Nidhi_Photo").resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height:150)
            Text("I'm a Computer Science & Management major. I love to read and play guitar. Above all, I love watching colourful sunsets.")
                .fixedSize(horizontal:false, vertical:true)
                .font(.body)
                .multilineTextAlignment(.center)
        }
        .padding(30)
        .frame(maxWidth:.infinity, maxHeight: .infinity)
        .background(.mint).ignoresSafeArea()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
