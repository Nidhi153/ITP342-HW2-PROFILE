//
//  ShahNidhiHW2App.swift
//  ShahNidhiHW2
//
//  Created by Student on 1/28/24.
//

import SwiftUI

@main
struct ShahNidhiHW2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
