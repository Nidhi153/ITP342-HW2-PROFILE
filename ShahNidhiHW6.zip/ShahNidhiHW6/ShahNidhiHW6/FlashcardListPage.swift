//
//  FlashcardListPage.swift
//  ShahNidhiHW6
//
//  Created by Student on 3/14/24.
//

import Foundation
import SwiftUI

struct FlashcardListPage: View {
    @StateObject var flashcardViewModel: FlashcardViewModel
    
    var body: some View {
        NavigationStack {
            List($flashcardViewModel.flashcards, id: \.self, editActions: .delete) { $flashcard in
                NavigationLink(value: flashcard) {
                    FlashcardCell(flashcard: flashcard)
                }
            }
            .navigationTitle("Flashcards")
            .toolbar {
                NavigationLink {
                    EditFlashcardPage()
                } label: {
                    Image(systemName: "plus")
                }
            }
            .navigationDestination(for: Flashcard.self) {
                EditFlashcardPage(flashcard: $0)
            }
        }
    }
}

struct FlashcardListPage_Previews: PreviewProvider {
    static var previews: some View {
        FlashcardListPage(flashcardViewModel: FlashcardViewModel())
    }
}
