//
//  Flashcard.swift
//  ShahNidhiHW6
//
//  Created by Student on 3/14/24.
//

import Foundation

struct Flashcard: Hashable, Identifiable, Codable {
    let id: String
    let question: String
    let answer: String
    let isFavorite: Bool
    
    static func == (lhs: Flashcard, rhs: Flashcard) ->  Bool {
        return (lhs.id == rhs.id && lhs.question == rhs.question && lhs.answer == rhs.answer && lhs.isFavorite == rhs.isFavorite)
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(question)
        hasher.combine(answer)
        hasher.combine(isFavorite)
    }
    init(id: String, question: String, answer: String, isFavorite: Bool) {
        self.id = id
        self.question = question
        self.answer = answer
        self.isFavorite = isFavorite
    }

}
