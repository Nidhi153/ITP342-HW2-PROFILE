//
//  EditFlashcardPage.swift
//  ShahNidhiHW6
//
//  Created by Student on 3/14/24.
//

import Foundation
import SwiftUI

struct EditFlashcardPage: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var flashcardViewModel: FlashcardViewModel
    private var flashcard: Flashcard?
    @State private var question = ""
    @State private var answer = ""
    @State private var isFavorite = false
    
    init(flashcard: Flashcard? = nil) {
        self.flashcard = flashcard
        if (flashcard != nil) {
            _question = State(initialValue: flashcard!.question)
            _answer = State(initialValue: flashcard!.answer)
            _isFavorite = State(initialValue: flashcard!.isFavorite)
        }
    }
    
    var body: some View {
        VStack(spacing:24) {
            TextField("Question", text: $question)
            TextField("Answer", text: $answer)
            Toggle("Is Favorite?", isOn: $isFavorite)
            Spacer()
        }
        .padding()
        .navigationTitle((flashcard == nil) ? "New Card" : "Edit Card")
        .toolbar {
            Button("Save") {
                if (flashcard != nil) {
                    let updatedCard = Flashcard(id: flashcard!.id, question: self.question, answer: self.answer, isFavorite: self.isFavorite)
                    if let ind = flashcardViewModel.getIndex(for: flashcard!) {
                        flashcardViewModel.update(flashcard: updatedCard, at: ind)
                    }
                }
                else {
                    let newCard = Flashcard(id: UUID().uuidString, question: self.question, answer: self.answer, isFavorite: self.isFavorite)
                    flashcardViewModel.append(flashcard: newCard)
                }
                dismiss()
            }
            .disabled((question == "" || answer == ""))
        }
    }
}

struct EditFlashcardPage_Previews: PreviewProvider {
    static var previews: some View {
        EditFlashcardPage(flashcard: FlashcardViewModel().flashcard(at: 2))
    }
}
