//
//  ShahNidhiHW6App.swift
//  ShahNidhiHW6
//
//  Created by Student on 3/14/24.
//

import SwiftUI

@main
struct ShahNidhiHW6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
