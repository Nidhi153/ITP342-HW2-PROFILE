//
//  MainTabView.swift
//  ShahNidhiHW6
//
//  Created by Student on 3/14/24.
//

import Foundation
import SwiftUI

struct MainTabView: View {
    @StateObject var flashcardViewModel: FlashcardViewModel = FlashcardViewModel()
    
    var body: some View {
        TabView {
            FlashcardPage(flashcardViewModel: flashcardViewModel)
                .tabItem {
                    Label("Question", systemImage: "questionmark")
                }
            FlashcardListPage(flashcardViewModel: flashcardViewModel)
                .tabItem {
                    Label("Cards", systemImage: "square.stack.3d.up.fill")
                }
            FavoritesFlashcardListPage(flashcardViewModel: flashcardViewModel)
                .tabItem {
                    Label("Favorites", systemImage: "star.fill")
                }
        }
        .environmentObject(flashcardViewModel)
    }
}
