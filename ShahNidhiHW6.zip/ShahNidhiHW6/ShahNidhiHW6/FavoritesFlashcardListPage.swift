//
//  FavoritesFlashcardListPage.swift
//  ShahNidhiHW6
//
//  Created by Student on 3/14/24.
//

import Foundation
import SwiftUI

struct FavoritesFlashcardListPage: View {
    @StateObject var flashcardViewModel: FlashcardViewModel
    
    var body: some View {
        NavigationStack {
            List(flashcardViewModel.favoriteFlashcards) { flashcard in
                NavigationLink(value: flashcard) {
                    FlashcardCell(flashcard: flashcard)
                }
            }
            .navigationTitle("Favorites")
            .navigationDestination(for: Flashcard.self) {
                EditFlashcardPage(flashcard: $0)
            }
        }
    }
}

struct FavoritesFlashcardListPage_Previews: PreviewProvider {
    static var previews: some View {
        FavoritesFlashcardListPage(flashcardViewModel: FlashcardViewModel())
    }
}
