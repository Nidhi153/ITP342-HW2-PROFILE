//
//  FlashcardViewModel.swift
//  ShahNidhiHW6
//
//  Created by Student on 3/14/24.
//

import Foundation

class FlashcardViewModel: FlashcardsModel, ObservableObject {
    
    @Published var flashcards: [Flashcard] {
        didSet {
            save()
        }
    }
    
    var numberOfFlashcards: Int {
        return flashcards.count
    }
    
    private let flashcardsFilePath: URL
    
    init() {
        flashcards = []
        
        let defaultCards = [
            Flashcard(id:UUID().uuidString, question:"Capital of China", answer:"Beijing", isFavorite:false),
            Flashcard(id:UUID().uuidString, question:"Capital of USA", answer:"Washington DC", isFavorite:false),
            Flashcard(id:UUID().uuidString, question:"Capital of India", answer:"Delhi", isFavorite:false),
            Flashcard(id:UUID().uuidString, question:"Capital of Australia", answer:"Canberra", isFavorite:false),
            Flashcard(id:UUID().uuidString, question:"Capital of Spain", answer:"Madrid", isFavorite:false),
        ]

        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileUrl = "\(url)/flashcards.json"
        flashcardsFilePath = URL(string: fileUrl)!
        print(fileUrl)
        
        flashcards = load() ?? defaultCards

    }
    
    @Published var currentIndex: Int? = 0 {
        didSet {
            if (currentIndex != nil) {
                switch (currentIndex!) {
                case flashcards.count...:
                    currentIndex=0
                default:
                    print("")
                }
            }
            if (flashcards.count<1) {
                currentIndex = nil
            }
        }
    }
    
    var currentFlashcard: Flashcard? {
        if (self.numberOfFlashcards == 0 || currentIndex == nil)  {
            return nil
        }
        //currentIndex is not nil
        if (currentIndex! >= self.numberOfFlashcards) {
            randomize()
        }
        return flashcards[currentIndex!]
    }
    
    var favoriteFlashcards: [Flashcard] {
        flashcards.filter{$0.isFavorite}
    }
    
    func getIndex(for flashcard: Flashcard) -> Int? {
        var i = 0
        while (i<numberOfFlashcards) {
            if (flashcards[i] == flashcard) {
                return i
            }
            i+=1
        }
        return nil
    }
    
    func randomize() {
        currentIndex = Int.random(in: 0..<flashcards.count)
        //use a while loop?
    }
    
    func next() {
        if (self.numberOfFlashcards <= 1 || self.currentIndex == nil) {
            return
        }
        currentIndex = currentIndex! + 1
        if (currentIndex! >= flashcards.count) {
            currentIndex = 0
        }
    }
    
    func previous() {
        if (self.numberOfFlashcards <= 1 || self.currentIndex == nil) {
            return
        }
        if (currentIndex == 0) {
            currentIndex = flashcards.count - 1
        }
        else {
            currentIndex = currentIndex! - 1
        }
    }
    
    func flashcard(at index: Int) -> Flashcard? {
        if (index < 0 || index >= flashcards.count) {
            return nil
        }
        return flashcards[index]
    }
    
    func append(flashcard: Flashcard) {
        flashcards.append(flashcard)
        if numberOfFlashcards == 1 {
            currentIndex = 0
        }
    }
    
    func insert(flashcard: Flashcard, at index: Int) {
        flashcards.append(flashcard)
        if (index < 0 || index >= flashcards.count) {
            return
        }
        for i in stride(from:numberOfFlashcards-1, through:index+1, by:-1){
            flashcards[i] = flashcards[i-1]
        }
        flashcards[index] = flashcard
    }
    
    func removeFlashcard(at index: Int) {
        if (index < 0 || index >= flashcards.count) {
            return
        }
        if (self.currentIndex == index && self.numberOfFlashcards > 0) {
            self.currentIndex = 0
        }
        flashcards.remove(at: index)
    }
    
    func toggleFavorite() {
        guard let currentIndex else {
            return
        }
        let currentCard: Flashcard = flashcards[currentIndex]
        let newCard: Flashcard = Flashcard(id: currentCard.id, question: currentCard.question, answer: currentCard.answer, isFavorite: !currentCard.isFavorite)
        self.update(flashcard: newCard, at: currentIndex)
        //do i need to destroy current card?
    }
    
    func update(flashcard: Flashcard, at index: Int) {
        if (index < 0 || index >= numberOfFlashcards) {
//            flashcards.append(flashcard)
            return
        }
        self.insert(flashcard: flashcard, at: index)
        self.removeFlashcard(at: index+1)
//        flashcards[index].id = flashcard.id
//        flashcards[index].question = flashcard.question
//        flashcards[index].answer = flashcard.answer
//        flashcards[index].isFavorite = flashcard.isFavorite
    }
    
    private func load()  -> [Flashcard]? {
        var flashcards: [Flashcard]? = nil
        do {
            let decoder = JSONDecoder()
            let data = try Data(contentsOf: flashcardsFilePath)
            flashcards = try decoder.decode([Flashcard].self, from: data)
        } catch {
            print(error)
        }
        return flashcards
    }
    
    private func save() {
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(flashcards)
            let str = String(data: data, encoding: .utf8)!
            
            do {
                try str.write(to:flashcardsFilePath, atomically: true, encoding: .utf8)
            }
        } catch {
            print(error)
        }
    }
    
}
