//
//  FlashcardCell.swift
//  ShahNidhiHW6
//
//  Created by Student on 3/14/24.
//

import Foundation
import SwiftUI

struct FlashcardCell: View {
    let flashcard: Flashcard
    
    init(flashcard: Flashcard) {
        self.flashcard = flashcard
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(flashcard.question)
                .font(.title3)
            Text(flashcard.answer)
                .font(.subheadline)
        }
    }
}

struct FlashcardCell_Previews: PreviewProvider {
    static var previews: some View {
        FlashcardCell(flashcard: FlashcardViewModel().flashcard(at: 2)!)
    }
}
