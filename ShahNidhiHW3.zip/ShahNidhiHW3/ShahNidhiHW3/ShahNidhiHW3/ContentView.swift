//
//  ContentView.swift
//  ShahNidhiHW3
//
//  Created by Student on 2/2/24.
//

import SwiftUI

struct ContentView: View {
    @FocusState private var isFocused : Bool
    @State private var name = ""
    @State private var message = ""
    var body: some View {
        ScrollView {
            VStack(spacing: 25) {
                
                Text("Which one do you like?")
                    .font(.largeTitle)
                    .multilineTextAlignment(.center)
                TextField("Name", text: $name)
                    .padding(16)
                    .background(Color.white)
                    .focused($isFocused)
                    .font(.title)
                    .multilineTextAlignment(.center)
                Image("dog")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height:120)
                
                Button("Dog") {
                    if name != "" {
                        message = "\(name), I woof you"
                    }
                    else {
                        message = "I woof you!"
                    }
                    isFocused = false
                }
                .padding(20)
                .frame(width:120)
                .background(Color.white)
                .font(.title2)
                
                
                Image("cat")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height:110)
                
                Button("Cat") {
                    if name != "" {
                        message = "\(name), you made the purrfect choice"
                    }
                    else {
                        message = "You made the purrfect choice!"
                    }
                    isFocused = false
                }
                .padding(20)
                .frame(width:120)
                .background(Color.white)
                .font(.title2)
                
                if (message != "") {
                    Text("\(message)")
                        .multilineTextAlignment(.center)
                }
                    
                
                Button("Reset") {
                    message = ""
                    name = ""
                    isFocused = false
                }
                .font(.title)
                .padding(20)
                .frame(maxWidth:.infinity)
                .background(Color.white)
            }
        }
        .padding(16)
        .background(Color.yellow)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
