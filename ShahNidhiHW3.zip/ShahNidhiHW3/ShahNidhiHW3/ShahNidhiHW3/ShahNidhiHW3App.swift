//
//  ShahNidhiHW3App.swift
//  ShahNidhiHW3
//
//  Created by Student on 2/2/24.
//

import SwiftUI

@main
struct ShahNidhiHW3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
